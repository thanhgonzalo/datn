<?php
/**
 * @link https://github.com/yii2-vn/payment
 * @copyright Copyright (c) 2017 Yii2VN
 * @license [New BSD License](http://www.opensource.org/licenses/bsd-license.php)
 *
 * PaymentClient information below get from https://github.com/naustudio/node-vn-payments
 */

return [
    'class' => 'yiiviet\payment\vnpayment\PaymentClient',
    'tmnCode' => 'COCOSIN',
    'hashSecret' => 'RAOEXHYVSDDIIENYWSLDIIZTANXUXZFJ'
];
