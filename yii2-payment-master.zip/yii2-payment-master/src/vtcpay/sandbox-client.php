<?php
/**
 * @link https://github.com/yii2-vn/payment
 * @copyright Copyright (c) 2017 Yii2VN
 * @license [New BSD License](http://www.opensource.org/licenses/bsd-license.php)
 *
 */

return [
    'class' => 'yiiviet\payment\vtcpay\PaymentClient',
    'secureCode' => 'baogomCHUHOAchuthuongso123vakytudacbiet!@#',
    'merchantId' => '74132',
    'business' => '0963465816'
];
