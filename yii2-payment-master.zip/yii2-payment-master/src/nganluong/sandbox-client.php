<?php
/**
 * @link https://github.com/yiiviet/yii2-payment
 * @copyright Copyright (c) 2017 Yii Viet
 * @license [New BSD License](http://www.opensource.org/licenses/bsd-license.php)
 *
 * PaymentClient information below get from https://github.com/naustudio/node-vn-payments
 */

return [
    'class' => 'yiiviet\payment\nganluong\PaymentClient',
    'email' => 'tung.tran@naustud.io',
    'merchantId' => 45571,
    'merchantPassword' => 'c57700e78cb0df1766279d91e3233c79'
];
