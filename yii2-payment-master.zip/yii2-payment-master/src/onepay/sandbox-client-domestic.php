<?php
/**
 * @link https://github.com/yiiviet/yii2-payment
 * @copyright Copyright (c) 2017 Yii Viet
 * @license [New BSD License](http://www.opensource.org/licenses/bsd-license.php)
 */

return [
    'class' => 'yiiviet\payment\onepay\PaymentClient',
    'merchantId' => 'ONEPAY',
    'accessCode' => 'D67342C2',
    'secureSecret' => 'A3EFDFABA8653DF2342E8DAC29B51AF0'
];
